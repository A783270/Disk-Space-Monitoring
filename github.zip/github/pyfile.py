import paramiko
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

k = paramiko.RSAKey.from_private_key_file("privatekey.pem", password = "")
c = paramiko.SSHClient()
c.set_missing_host_key_policy(paramiko.AutoAddPolicy())
print("connecting")
c.connect( hostname = "10.22.5.34", port = "122",username = "admin" ,pkey = k )
print("connected")

commands = ["df /dev/sda1" ]
for command in commands:
    print("Hello")
    print("="*50, command, "="*50)
    stdin, stdout, stderr = c.exec_command(command)
    usage = stdout.read().decode().split()
    err = stderr.read().decode()
    if err:
        print(err)
Threshold = int(usage[11].strip('%'))
if Threshold > 90 :
        print("Disk Space Running out")
else:
        print("Mail Process")
        msg = MIMEMultipart()
        msg['From'] = 'tushar.deshmukh@atos.net'
        msg['To'] = 'tushar.deshmukh@atos.net'
        msg['Subject'] = 'SMTP Mail'
        body = 'Testing Purpose Body Mail'
        msg.attach(MIMEText(body, 'plain'))
        server = smtplib.SMTP('10.22.5.109', 25)  ### put your relevant SMTP here
        #server.login('from@domain.com', 'password_here')  ### if applicable
        server.send_message(msg)
        server.quit()

