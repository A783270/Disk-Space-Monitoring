# -*- coding: utf-8 -*-
"""
Created on Thu Jul  2 19:19:38 2020

@author: a783270
"""

import requests

headers = {"Authorization": "Bearer 0390f73339090cd03827fe6dc821343b30e8735e"}


def run_query(query): # A simple function to use requests.post to make the API call. Note the json= section.
    request = requests.post('https://api.github.com/graphql', json={'query': query}, headers=headers)
    if request.status_code == 200:
        return request.json()
    else:
        raise Exception("Query failed to run by returning code of {}. {}".format(request.status_code, query))

        
# The GraphQL query (with a few aditional bits included) itself defined as a multi-line string.       
query = """
{
  viewer {
    login
    avatarUrl
  }
  
  repositoryOwner(login:"wintushar09")
  { 
    repositories{
      totalCount
    }
  }
}
"""

result = run_query(query) # Execute the query

#avatarurl = result["data"]["viewer"]["login"]
print(result)