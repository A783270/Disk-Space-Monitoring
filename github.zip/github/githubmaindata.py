# -*- coding: utf-8 -*-
"""
Created on Thu Jul  9 19:50:30 2020

@author: a783270
"""

# -*- coding: utf-8 -*-
"""
Created on Thu Jul  2 19:19:38 2020

@author: a783270
"""

import xlsxwriter 
import requests
from flatten_json import flatten 


headers = {"Authorization": "Bearer 025522172021fed6d6b86e7ed53b892e74c603b9"}


def run_query(query): # A simple function to use requests.post to make the API call. Note the json= section.
    request = requests.post('https://api.github.com/graphql', json={'query': query}, headers=headers)
    if request.status_code == 200:
        return request.json()
    else:
        raise Exception("Query failed to run by returning code of {}. {}".format(request.status_code, query))

        
# The GraphQL query (with a few aditional bits included) itself defined as a multi-line string.       
query = """
{
 organization(login:"CNSJ-FRANCE") {
      auditLog(last:100){
        edges{
          node{
            ... on AuditEntry {
              action
              actorLogin
              createdAt
              
              
            }
          }
        }
      }
    }
}
"""

result = run_query(query) 
flat_json = flatten(result)
#data = json.dumps(result, indent=4, sort_keys=True)
#print(flat_json)
#data = json_normalize(flat_json)
#data = json_normalize(result)
#person_dict = json.dumps(result, indent = 4, sort_keys=True)
#
#print(data)
action=[]
actorLogin=[]
createdAt=[]
#print("node_action"'\t\t'"node_actorLogin"'\t\t'"createdAt"'\t\t')
for x in range(99):  
    action.append(flat_json[f"data_organization_auditLog_edges_{x}_node_action"])
    actorLogin.append(flat_json[f"data_organization_auditLog_edges_{x}_node_actorLogin"])
    createdAt.append(flat_json[f"data_organization_auditLog_edges_{x}_node_createdAt"])
    #print(flat_json[f"data_organization_auditLog_edges_{x}_node_action"],flat_json[f"data_organization_auditLog_edges_{x}_node_actorLogin"],flat_json[f"data_organization_auditLog_edges_{x}_node_createdAt"]) 
    #print('\n')
    
#parsed_json = (json.loads(person_dict))
for x in range(99):
    print(action[x],actorLogin[x],createdAt[x])
#print(parsed_json['data'].keys())
#print(type(flat_json)) 
#conv = Converter()
#conv.convert(flat_json, Writer(file='test.xlsx'))


#with open('data.json', 'w') as outfile:
#    json.dump(flat_json, outfile , indent = 4)
#    
#with open('data.json', 'r') as data_file:
#    data = json.load(data_file)
#
#for element in data:
#    element.pop(0, None)
#
#with open('data.json', 'w') as data_file:
#    data = json.dump(data, data_file)    