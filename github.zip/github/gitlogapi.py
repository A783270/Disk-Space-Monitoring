# -*- coding: utf-8 -*-
"""
Created on Fri Jul  3 11:57:09 2020

@author: a783270
"""

import requests

headers = {"Authorization" : "Bearer 0390f73339090cd03827fe6dc821343b30e8735e"}

def run_query(query):
    request = requests.post('https://api.github.com/graphql', json={'query':query},headers=headers)
    if request.status_code == 200:
        return request.json()
    else:
        raise Exception("error occured".format(request.status_code,query))
    
query = """
{
    organization(login:"Shadowsfc") {
      auditLog(last:100){
        edges{
          node{
            ... on AuditEntry {
              action
              actorLogin
              createdAt
              
              
            }
          }
        }
      }
    }                
}
"""
result = run_query(query)
print(result)

    