const mongodb = require('mongodb');
const MongoClient = mongodb.MongoClient
const url = "mongodb://127.0.0.1:27017";

var _db;

module.exports = {

    connectToServer: async (callback) => {
       await MongoClient.connect(url, { useNewUrlParser: true, useUnifiedTopology: true }, function (err, client) {
 
           _db = client.db('new-task');
           return callback(err);
        });
    },

    getDb: function () {
        
        return _db;
    }
}

