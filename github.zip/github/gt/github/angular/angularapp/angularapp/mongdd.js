var mongoUtil = require('./connect/conn');
const readline = require('readline');

 
insertOp = async () => {
    try {

       mongoUtil.connectToServer(function (err, client) {
          if (err) {
              console.log(err);
          }
           
        var db = mongoUtil.getDb();
           db.collection('users').insertMany([
               {
                   name: "Tushar",
                   loc: "Pune"
               }
               ,
               {
                   name: "Lalit",
                   loc: "Nashik"

               }
        ], (error, result) => {
            if (error) {
                return console.log('unable to insert user')
            }
            console.log(result.ops)
        })
      });
    } catch (err) {
        console.log("Failed to connect!")
        console.log(err) 
    }
}




Searchop = async () => {
  
        mongoUtil.connectToServer(function (err, client) {
            if (err) {
                console.log(err);
            }

            var db = mongoUtil.getDb();
        
           
            const name = readline.createInterface({
                input: process.stdin,
                output: process.stdout
            });

            name.question('name to search ', (answer) => {

                db.collection('users').findOne({ name: answer }, (error, user) => {
                    if (error) console.log("user not found")

                    console.log(user)
                })

                name.close();
            });

          
        })
    
}


const opt = readline.createInterface({
    input: process.stdin,
    output: process.stdout
});


insertOp()
Searchop()





//insertOp()
//Searchop()



