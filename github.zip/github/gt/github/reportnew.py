# -*- coding: utf-8 -*-
"""
Created on Tue Jul 21 14:18:52 2020

@author: a783270
"""

    # -*- coding: utf-8 -*-
"""
Created on Thu Jul 16 11:00:22 2020

@author: a783270
"""

import requests
import csv


url = "https://stggithub.gsissc.myatos.net/stafftools/reports/all_repositories.csv"
username = "A783270"
password = "3e0cdfe233f11d3981a5dffee87da98149aa6f3e"

response = requests.get(url,auth=(username,password))
decoded_content = response.content.decode('utf-8')

csv_reader = csv.reader(decoded_content.splitlines() ,  delimiter=',')
with open('file.csv', 'w') as csvFile:
    
    mylist = list(csv_reader)
    csv_writer = csv.writer(csvFile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
    for row in mylist:
        
        csv_writer.writerow(row)
    csvFile.close()
    
with open('file.csv') as csvfile:
     reader = csv.DictReader(csvfile)
     for row in reader:
         print(row['created_at'])