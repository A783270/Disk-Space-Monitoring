# -*- coding: utf-8 -*-
"""
Created on Wed Jul 22 13:25:59 2020

@author: a783270
"""

    # -*- coding: utf-8 -*-
"""
Created on Thu Jul 16 11:00:22 2020

@author: a783270
"""


import csv
import mysql.connector
from datetime import datetime,timedelta
import os
import all_repositories
import active_user
import all_org

all_repositories.repos() #function to get the repos data and stored in .csv file
active_user.act_users() #function to get the active users data and stored in .csv file
all_org.all_org()  #function to get the all orgaization data and stored in .csv file


now = datetime.now()
formatted_date = now.strftime('%Y-%m-%d')  #current date



mydb = mysql.connector.connect(                 #sql connection for inserting csv data in tables
  host="localhost",
  user="root",
  password="Tushar@09",
  database="reports"
)
mycursor = mydb.cursor()

                    #store all_repository data in report5 table
                    
sql = "INSERT INTO report5(created_at,owner_id, owner_type,owner_name,id,name,visibility,readable_size,raw_size,collaborators,fork,deleted,currentdate) VALUES (%s , %s , %s , %s, %s, %s , %s , %s , %s ,%s , %s, %s, %s)"  
with open('all_repos.csv') as csvfile:              
     reader = csv.DictReader(csvfile)
     for row in reader:
         val = (row['created_at'],row['owner_id'],row['owner_type'],row['owner_name'],row['id'],row['name'],row['visibility'],row['readable_size'],row['raw_size'],row['collaborators'],row['fork?'],row['deleted?'],formatted_date)
         mycursor.execute(sql, val)
         mycursor.nextset

mydb.commit()
print(mycursor.rowcount, "repos inserted.")  


                               #store all_users data in all_users1 table
                               
sql = "INSERT INTO all_users1(created_at,id,login,email,role,suspended,last_login,repos,ssh_keys,org_membership,dormant,last_active,raw_login,2fa_enabled,currentdate) VALUES (%s , %s , %s , %s, %s, %s , %s , %s , %s ,%s , %s, %s, %s, %s, %s)"
with open('act_users.csv') as csvfile:
     reader = csv.DictReader(csvfile)
     for row in reader:
         val = (row['created_at'],row['id'],row['login'],row['email'],row['role'],row['suspended?'],row['last_logged_ip'],row['repos'],row['ssh_keys'],row['org_memberships'],row['dormant?'],row['last_active'],row['raw_login'],row['2fa_enabled?'],formatted_date)
         mycursor.execute(sql, val)
         mycursor.nextset

mydb.commit()
print(mycursor.rowcount, "all_users inserted.")
   

                             #store all_orgaization data in all_orgs table
                                                         
sql = "INSERT INTO all_orgs(id,created_at,login,email,admins,members,teams,repos,2fa_required,currentdate) VALUES (%s , %s , %s , %s, %s, %s , %s , %s , %s ,%s)"
with open('all_orgs.csv') as csvfile:
     reader = csv.DictReader(csvfile)
     for row in reader:
         val = (row['id'],row['created_at'],row['login'],row['email'],row['admins'],row['members'],row['teams'],row['repos'],row['2fa_required?'],formatted_date)
         mycursor.execute(sql, val)
         mycursor.nextset

mydb.commit()
print(mycursor.rowcount, "all_orgs inserted.")
   

#removing .csv file from local machine
os.remove('all_repos.csv')
os.remove('act_users.csv')
os.remove('all_orgs.csv')



#function to fetch data of last 3months from database and store in csv file 
today = datetime.now()
dd = today - timedelta(days=90) 
dd = dd.strftime('%Y-%m-%d')
print(dd)

sql = "select * from all_users1 where currentdate BETWEEN '%s' AND '%s'" % (dd,formatted_date)
mycursor.execute(sql)

myresult =  mycursor.fetchall()
for x in myresult:
  print(x)


mydb.close