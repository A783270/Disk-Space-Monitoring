# -*- coding: utf-8 -*-
"""
Created on Wed Jul 22 16:35:05 2020

@author: a783270
"""

import requests
import csv


def all_org():
    url = "https://stggithub.gsissc.myatos.net/stafftools/reports/all_organizations.csv"
    username = "A783270"
    password = "3e0cdfe233f11d3981a5dffee87da98149aa6f3e"

    response = requests.get(url,auth=(username,password))
    all_orgs = response.content.decode('utf-8')

    csv_reader = csv.reader(all_orgs.splitlines() ,  delimiter=',')
    with open('all_orgs.csv', 'w') as csvFile:
    
        mylist = list(csv_reader)
        csv_writer = csv.writer(csvFile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
        for row in mylist:
            csv_writer.writerow(row)
            
        csvFile.close()
        
