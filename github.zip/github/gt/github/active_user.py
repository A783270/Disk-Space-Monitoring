# -*- coding: utf-8 -*-
"""
Created on Wed Jul 22 16:35:05 2020

@author: a783270
"""


import requests
import csv

def act_users():
    url = "https://stggithub.gsissc.myatos.net/stafftools/reports/active_users.csv"
    username = "A783270"
    password = "3e0cdfe233f11d3981a5dffee87da98149aa6f3e"

    response = requests.get(url,auth=(username,password))
    active_us = response.content.decode('utf-8')

    csv_reader = csv.reader(active_us.splitlines() ,  delimiter=',')
    with open('act_users.csv', 'w') as csvFile:
    
        mylist = list(csv_reader)
        csv_writer = csv.writer(csvFile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
        for row in mylist:
            csv_writer.writerow(row)
            
        csvFile.close()