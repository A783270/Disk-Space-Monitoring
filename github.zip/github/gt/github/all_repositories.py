# -*- coding: utf-8 -*-
"""
Created on Wed Jul 22 16:28:32 2020

@author: a783270
"""


import requests
import csv

def repos():
    url = "https://stggithub.gsissc.myatos.net/stafftools/reports/all_repositories.csv"
    username = "A783270"
    password = "3e0cdfe233f11d3981a5dffee87da98149aa6f3e"

    response = requests.get(url,auth=(username,password))
    all_repositories = response.content.decode('utf-8')


    csv_reader = csv.reader(all_repositories.splitlines() ,  delimiter=',')
    with open('all_repos.csv', 'w') as csvFile:
    
        mylist = list(csv_reader)
        csv_writer = csv.writer(csvFile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
        for row in mylist:
            csv_writer.writerow(row)
        csvFile.close()