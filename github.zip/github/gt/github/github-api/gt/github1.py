# -*- coding: utf-8 -*-
"""
Created on Thu Jul  2 19:19:38 2020

@author: a783270
"""

import xlsxwriter 
import requests
from flatten_json import flatten 


headers = {"Authorization": "Bearer 025522172021fed6d6b86e7ed53b892e74c603b9"}


def run_query(query): # A simple function to use requests.post to make the API call. Note the json= section.
    request = requests.post('https://api.github.com/graphql', json={'query': query}, headers=headers)
    if request.status_code == 200:
        return request.json()
    else:
        raise Exception("Query failed to run by returning code of {}. {}".format(request.status_code, query))

        
# The GraphQL query (with a few aditional bits included) itself defined as a multi-line string.       
query = """
{
 organization(login:"CNSJ-FRANCE") {
      auditLog(last:100){
        edges{
          node{
            ... on AuditEntry {
              action
              actorLogin
              createdAt
              
              
            }
          }
        }
      }
    }
}
"""

result = run_query(query) 
flat_json = flatten(result)

action=[]
actorLogin=[]
createdAt=[]
#print("node_action"'\t\t'"node_actorLogin"'\t\t'"createdAt"'\t\t')
for x in range(99):  
    action.append(flat_json[f"data_organization_auditLog_edges_{x}_node_action"])
    actorLogin.append(flat_json[f"data_organization_auditLog_edges_{x}_node_actorLogin"])
    createdAt.append(flat_json[f"data_organization_auditLog_edges_{x}_node_createdAt"])
    
#for x in range(99):
#    print(action[x],actorLogin[x],createdAt[x])
#    
workbook = xlsxwriter.Workbook('Example2.xlsx') 
worksheet = workbook.add_worksheet()
row = 0
column = 0
worksheet.write(row,column,'action')
row += 1
for item in action : 
    worksheet.write(row, column, item) 
    row += 1
    
row = 0 
column += 1
worksheet.write(row,column,'actorLogin')
row += 1
for item in actorLogin :
    worksheet.write(row, column, item) 
    row += 1
    
row = 0    
column += 1
worksheet.write(row,column,'createdAt')
row += 1
for item in createdAt :
    worksheet.write(row, column, item) 
    row += 1
    
workbook.close() 
