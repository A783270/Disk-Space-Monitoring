    # -*- coding: utf-8 -*-
"""
Created on Thu Jul 16 11:00:22 2020

@author: a783270
"""

import requests
import csv

url = "https://stggithub.gsissc.myatos.net/stafftools/reports/all_repositories.csv"
username = "A783270"
password = "3e0cdfe233f11d3981a5dffee87da98149aa6f3e"

response = requests.get(url,auth=(username,password))
decoded_content = response.content.decode('utf-8')

#cr = csv.reader(decoded_content.splitlines(), delimiter=',')
#
#my_list = list(cr)
#
#for row in my_list:
#    print(row)
#
#with open("temp_csv6.csv", 'w') as temp_file:
#
#    temp_file.writelines(decoded_content)


#with open('out.csv', 'w') as f:
#    writer = csv.writer(f)
#  
#    for line in response.iter_lines():
#     
#        writer.writerow(line.decode('utf-8').split(','))


csv_reader = csv.reader(decoded_content.splitlines() ,  delimiter=',')
with open('file.csv', 'w') as csvFile:
    
    mylist = list(csv_reader)
    csv_writer = csv.writer(csvFile, delimiter=',', quoting=csv.QUOTE_MINIMAL)
    for row in mylist:
        csv_writer.writerow(row)
    csvFile.close()