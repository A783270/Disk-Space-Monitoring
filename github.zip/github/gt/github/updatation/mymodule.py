# -*- coding: utf-8 -*-
"""
Created on Mon Jul 20 13:34:38 2020

@author: a783270
"""

# -*- coding: utf-8 -*-
"""
Created on Fri Jul 10 14:52:59 2020

@author: a783270
"""

from flatten_json import flatten 
import xlsxwriter

def conv(data):
    flat_json = flatten(data)
    
    action=[]
    actorLogin=[]
    createdAt=[]
    actorResourcePath = []
    operationType = []
    actorUrl = []
    userLogin = []
    userUrl = [] 
    userResourcePath = [] 
    email = []              

    for x in range(99):  
        action.append(flat_json[f"data_organization_auditLog_edges_{x}_node_action"])
        actorLogin.append(flat_json[f"data_organization_auditLog_edges_{x}_node_actorLogin"])
        createdAt.append(flat_json[f"data_organization_auditLog_edges_{x}_node_createdAt"])
        actorResourcePath.append(flat_json[f"data_organization_auditLog_edges_{x}_node_actorResourcePath"])
        operationType.append(flat_json[f"data_organization_auditLog_edges_{x}_node_operationType"])
        actorUrl.append(flat_json[f"data_organization_auditLog_edges_{x}_node_actorUrl"])
        userLogin.append(flat_json[f"data_organization_auditLog_edges_{x}_node_userLogin"])
        userUrl.append(flat_json[f"data_organization_auditLog_edges_{x}_node_userUrl"])
        userResourcePath.append(flat_json[f"data_organization_auditLog_edges_{x}_node_userResourcePath"])
        
     
        try:
           email.append(flat_json[f"data_organization_auditLog_edges_{x}_node_user_email"])
        except KeyError:
            email.append("NULL")
        
    workbook = xlsxwriter.Workbook('Auditlogs.xlsx') 
    worksheet = workbook.add_worksheet()
    
    row = 0
    column = 0
    
    worksheet.write(row,column,'action')
    for item in action : 
        row += 1
        worksheet.write(row, column, item) 
        
    
    row = 0 
    column += 1
    worksheet.write(row,column,'actorLogin')
    
    for item in actorLogin :
        row += 1
        worksheet.write(row, column, item) 
       
    
    row = 0    
    column += 1
    worksheet.write(row,column,'createdAt')
    for item in createdAt :
        row += 1
        worksheet.write(row, column, item) 
        
        
    row = 0
    column += 1
    worksheet.write(row,column,'actorResourcePath')
    for item in actorResourcePath :
        row += 1
        worksheet.write(row, column, item) 
        
    row = 0
    column += 1
    worksheet.write(row,column,'operationType')
    for item in operationType :
        row += 1
        worksheet.write(row, column, item) 
      
   
    row = 0
    column += 1
    worksheet.write(row,column,'actorUrl')
    for item in actorUrl :
        row += 1
        worksheet.write(row, column, item) 
        
     
    row = 0    
    column += 1
    worksheet.write(row,column,'userLogin')
    for item in userLogin :
        row += 1
        worksheet.write(row, column, item) 
        
    row = 0   
    column += 1
    worksheet.write(row,column,'userUrl')
    for item in userUrl :
        row += 1
        worksheet.write(row, column, item)   
    
    row = 0
    column += 1
    worksheet.write(row,column,'userResourcePath')
    for item in userResourcePath :
        row += 1
        worksheet.write(row, column, item)   
        
    
    row = 0
    column += 1
    worksheet.write(row,column,'Email')
    for item in email :
        row += 1
        worksheet.write(row, column, item) 
        
    workbook.close() 
    return workbook.filename        