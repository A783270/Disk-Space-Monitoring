# -*- coding: utf-8 -*-
"""
Created on Wed Jul 15 10:43:33 2020

@author: a783270


from requests_oauthlib import OAuth2Session
import requests
from requests_oauthlib import OAuth2
client_key = "fab4cc7de42145b9a4c7"
client_secret = "b386291921aaa72d4ef3cbd8fddb1d84c6a7c2a5"

request_token_url = 'https://github.com/login/oauth/authorize'

oauth = OAuth2Session(client_key, client_secret=client_secret)
#oauth = OAuth2Session(client_key)
#fetch_response = oauth.fetch_request_token(request_token_url)
fetch_response = oauth.fetch_token(request_token_url)
print(fetch_response)
"""

import requests
import json
url = "https://github.com/login/oauth/authorize?client_id=fab4cc7de42145b9a4c7&scope=user:email%20public_repo?client_id=fab4cc7de42145b9a4c7&Client_Secret=b386291921aaa72d4ef3cbd8fddb1d84c6a7c2a5"

payload = {}

response = requests.request("GET", url, data = payload)

response
print(json.dumps(response.content, indent = 4 , sort_keys= True))
