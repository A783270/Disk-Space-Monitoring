# -*- coding: utf-8 -*-
"""
Created on Tue Jul 14 17:31:59 2020

@author: a783270
"""

import requests

#import xlrd
import json
headers = {"Authorization": "Bearer 025522172021fed6d6b86e7ed53b892e74c603b9"}


def run_query(query): # A simple function to use requests.post to make the API call. Note the json= section.
    request = requests.post('https://api.github.com/graphql', json={'query': query}, headers=headers)
    if request.status_code == 200:
        return request.json()
    else:
        raise Exception("Query failed to run by returning code of {}. {}".format(request.status_code, query))

        
# The GraphQL query (with a few aditional bits included) itself defined as a multi-line string.       
query = """
{
  organization(login: "CNSJ-FRANCE") {
    auditLog(last:100) {
      edges {
        node {
          ... on AuditEntry {
# Get Audit Log Entry by 'Action'
            action
            actorLogin
            createdAt
# User 'Action' was performed on
           user{
              name
                email
            }
          }
        }
      }
    }
  }
}
"""

result = run_query(query)
print(json.dumps(result, indent = 4 , sort_keys= True))