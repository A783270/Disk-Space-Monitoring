# -*- coding: utf-8 -*-
"""
Created on Fri Jul 17 12:27:24 2020

@author: a783270


import schedule
import time

def job():
    print("starting the service")

def code():
    print("code was started")


schedule.every(1).seconds.do(job)
schedule.every(1).day.hour.

while True:
    schedule.run_pending()
    time.sleep(6)
"""


from datetime import date
from schedule import Scheduler 






def job2():
    print("hello")
    if date.today().day != 1:
        print("hello i am here")
        return

    # actual job body
    
Scheduler.every(1).day.at("02:00").do(job2)

