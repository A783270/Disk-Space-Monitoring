# -*- coding: utf-8 -*-
"""
Created on Wed Jul 15 18:29:43 2020

@author: a783270
"""

import requests

#import xlrd
import json
headers = {"Authorization": "Bearer 3e0cdfe233f11d3981a5dffee87da98149aa6f3e"}


def run_query(query): # A simple function to use requests.post to make the API call. Note the json= section.
    request = requests.post('https://stggithub.gsissc.myatos.net/enterprises/atos-international', json={'query': query}, headers=headers)
    if request.status_code == 200:
        return request.json()
    else:
        raise Exception("Query failed to run by returning code of {}. {}".format(request.status_code, query))

        
# The GraphQL query (with a few aditional bits included) itself defined as a multi-line string.       
query = """
  enterprise(slug:"atos-international") {
    ...enterpriseFragment
  }
}

fragment enterpriseFragment on Enterprise {
  ... on Enterprise{
    name
    organizations(first: 100){
      nodes{
        name
        ... on Organization{
          name
          repositories(privacy: PUBLIC){
            totalCount
          }
        }
      }
    }
  }
}

"""

result = run_query(query)
print(json.dumps(result, indent = 4 , sort_keys= True))