# -*- coding: utf-8 -*-
"""
Created on Fri Jul 17 13:54:39 2020

@author: a783270


	
from crontab import CronTab

my_cron = CronTab(user='a783270')

for job in my_cron:
    print job
"""

from crontab import CronTab

file_cron = CronTab(tabfile='/corn1.txt')
mem_cron = CronTab(tab="""
  * * * * * command
""")