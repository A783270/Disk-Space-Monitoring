# -*- coding: utf-8 -*-
"""
Created on Thu Jul 16 12:56:30 2020

@author: a783270
"""

from datetime import datetime 
  
  
# Saves a .txt file with file name 
# as 2020-01-11-10-20-23.txt 
with open(datetime.now().strftime("%Y-%m-%d"), "w")as myfile: 
      
    # Content of the file 
    myfile.write("Hello World !") 