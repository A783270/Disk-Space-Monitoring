# -*- coding: utf-8 -*-
"""
Created on Fri Jul 17 13:53:16 2020

@author: a783270
"""

import datetime
 
with open('dateInfo.txt','a') as outFile:
    outFile.write('\n' )