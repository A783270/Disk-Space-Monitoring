# -*- coding: utf-8 -*-
"""
Created on Tue Jul 14 17:58:17 2020

@author: a783270
"""

import requests

#import xlrd
import json
headers = {"Authorization": "Bearer 3e0cdfe233f11d3981a5dffee87da98149aa6f3e"}


def run_query(query): # A simple function to use requests.post to make the API call. Note the json= section.
    request = requests.post('https://stggithub.gsissc.myatos.net/api/graphql', json={'query': query}, headers=headers)
    if request.status_code == 200:
        return request.json()
    else:
        raise Exception("Query failed to run by returning code of {}. {}".format(request.status_code, query))

        
# The GraphQL query (with a few aditional bits included) itself defined as a multi-line string.       
query = """
{
 organization(login:"KI-SSC-GitHub") {
      auditLog(last:100){
        edges{
          node{
            ... on AuditEntry {
              action
              actorLogin
              createdAt
              actorResourcePath
              operationType
              actorUrl
              userLogin 
              userUrl 
              userResourcePath 
              
            }
          }
        }
      }
    }
}

"""

result = run_query(query)
print(json.dumps(result, indent = 4 , sort_keys= True))