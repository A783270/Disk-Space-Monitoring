# -*- coding: utf-8 -*-
"""
Created on Thu Jul  2 19:19:38 2020

@author: a783270
"""
import requests
import mymodule
import xlrd
import json
headers = {"Authorization": "Bearer 025522172021fed6d6b86e7ed53b892e74c603b9"}


def run_query(query): # A simple function to use requests.post to make the API call. Note the json= section.
    request = requests.post('https://api.github.com/graphql', json={'query': query}, headers=headers)
    if request.status_code == 200:
        return request.json()
    else:
        raise Exception("Query failed to run by returning code of {}. {}".format(request.status_code, query))

        
# The GraphQL query (with a few aditional bits included) itself defined as a multi-line string.       
query = """
{
 organization(login:"CNSJ-FRANCE") {
      auditLog(last:100){
        edges{
          node{
            ... on AuditEntry {
              action
              actorLogin
              createdAt
              actorResourcePath
              operationType
              actorUrl
              userLogin 
              userUrl 
              userResourcePath 
              user
              {
                      email
                      url
                      Resourcepath 
              }
              
            }
          }
        }
      }
    }
}
"""

result = run_query(query) 
print(json.dumps(result, indent = 4 , sort_keys= True))
#res = mymodule.conv(result)
#loc = ("Example2.xlsx") 
#wb = xlrd.open_workbook(loc) 
#sheet = wb.sheet_by_index(0) 
#for i in range(sheet.nrows): 
#    print(sheet.cell_value(i,4)) 
print(res)