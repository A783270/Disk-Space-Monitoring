# -*- coding: utf-8 -*-
"""
Created on Fri Jul 10 15:32:35 2020

@author: a783270
"""
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 10 14:52:59 2020

@author: a783270
"""

from flatten_json import flatten 
import xlsxwriter 

def conv(data):
    flat_json = flatten(data)

    action=[]
    actorLogin=[]
    createdAt=[]
    actorResourcePath = []
#print("node_action"'\t\t'"node_actorLogin"'\t\t'"createdAt"'\t\t')
    for x in range(99):  
        action.append(flat_json[f"data_organization_auditLog_edges_{x}_node_action"])
        actorLogin.append(flat_json[f"data_organization_auditLog_edges_{x}_node_actorLogin"])
        createdAt.append(flat_json[f"data_organization_auditLog_edges_{x}_node_createdAt"])
        actorResourcePath.append(flat_json[f"data_organization_auditLog_edges_{x}_node_actorResourcePath"])
#for x in range(99):
#    print(action[x],actorLogin[x],createdAt[x])
#    
    workbook = xlsxwriter.Workbook('Example2.xlsx') 
    worksheet = workbook.add_worksheet()
    row = 0
    
    column = 0
    worksheet.write(row,column,'action')
    row += 1
    for item in action : 
        for j in column :
            print(j)
            worksheet.write(row, column, item) 
            row += 1
    
    row = 0 
    column += 1
    worksheet.write(row,column,'actorLogin')
    row += 1
    for item in actorLogin :
        worksheet.write(row, column, item) 
        row += 1
    
    row = 0    
    column += 1
    worksheet.write(row,column,'createdAt')
    row += 1
    for item in createdAt :
        worksheet.write(row, column, item) 
        row += 1
    
    workbook.close() 
    return workbook.filename