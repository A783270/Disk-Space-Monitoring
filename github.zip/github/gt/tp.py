# -*- coding: utf-8 -*-
"""
Created on Fri Jul 10 15:37:34 2020

@author: a783270
"""

a = 1 
for i in a(1,10) :
    print(a)